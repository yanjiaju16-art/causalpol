"""
causalpol.taxonomy.schema
=========================
Core data structures for the CausalPol annotation taxonomy.

The taxonomy follows the four-way causal type classification and three-way
epistemic status classification described in Section 3.2 of the paper.

Classes
-------
CausalType
    Enumeration of causal relationship types (mechanistic, correlational,
    counterfactual, definitional).

EpistemicStatus
    Enumeration of evidential standing of causal claims (established,
    contested, speculative).

PolicyDomain
    Enumeration of the seven policy domains in PolCausal-50K.

Language
    ISO 639-1 codes for the six languages covered.

CausalClaim
    Dataclass representing a single extracted and annotated causal claim.

InconsistencyType
    Enumeration of cross-claim inconsistency categories.

InconsistencyPair
    Dataclass representing a pair of inconsistent causal claims.

PipelineResult
    Container for all outputs of a CausalPolPipeline.run() call.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class CausalType(str, Enum):
    """
    Four-way classification of causal claim types.

    Attributes
    ----------
    MECHANISTIC :
        The document specifies an intermediate mechanism linking cause and
        effect (e.g., "higher rates → reduced borrowing → lower demand →
        lower inflation").
    CORRELATIONAL :
        Co-occurrence or association is asserted without mechanistic
        specification (e.g., "periods of high unemployment coincide with
        lower inflation").
    COUNTERFACTUAL :
        The claim takes the form of a conditional assertion about what would
        occur in the absence of the cause (e.g., "without the subsidy,
        renewable deployment would have stalled").
    DEFINITIONAL :
        Causal language is used to constitute or define a concept rather
        than to make an empirical prediction (e.g., "a recession is caused
        by two consecutive quarters of negative GDP growth").
    """

    MECHANISTIC = "mechanistic"
    CORRELATIONAL = "correlational"
    COUNTERFACTUAL = "counterfactual"
    DEFINITIONAL = "definitional"


class EpistemicStatus(str, Enum):
    """
    Three-way classification of the evidential standing of a causal claim.

    Attributes
    ----------
    ESTABLISHED :
        Presented as settled or supported by cited evidence.
    CONTESTED :
        The document acknowledges uncertainty or expert disagreement.
    SPECULATIVE :
        Forward-looking or explicitly uncertain (predictions, projections).
    """

    ESTABLISHED = "established"
    CONTESTED = "contested"
    SPECULATIVE = "speculative"


class PolicyDomain(str, Enum):
    """
    Seven policy domains covered by PolCausal-50K.

    These correspond to the domain-stratified partitions used for training
    and evaluation (Table 1 of the paper).
    """

    MONETARY_POLICY = "monetary_policy"
    FISCAL_POLICY = "fiscal_policy"
    PHARMACEUTICAL_REGULATION = "pharmaceutical_regulation"
    ENVIRONMENTAL_REGULATION = "environmental_regulation"
    LABOR_MARKET_POLICY = "labor_market_policy"
    TRADE_POLICY = "trade_policy"
    TECHNOLOGY_REGULATION = "technology_regulation"


class Language(str, Enum):
    """
    Six languages covered by CausalPol, in descending extraction performance
    order (Section 5.2 of the paper).
    """

    ENGLISH = "en"
    FRENCH = "fr"
    GERMAN = "de"
    SPANISH = "es"
    ITALIAN = "it"
    POLISH = "pl"


class InconsistencyType(str, Enum):
    """
    Four-way classification of cross-claim inconsistency types (Table 2).

    Attributes
    ----------
    DIRECTIONAL :
        Same policy instrument claimed to both increase and decrease the same
        outcome (prevalence 2.8% in EU regulatory impact assessments).
    MAGNITUDE :
        Same directional claim with incompatible magnitude assertions (1.9%).
    SCOPE :
        Claims about different populations with incompatible policy
        implications (1.1%).
    TEMPORAL :
        Short-run and long-run claims not appropriately distinguished (0.5%).
    """

    DIRECTIONAL = "directional"
    MAGNITUDE = "magnitude"
    SCOPE = "scope"
    TEMPORAL = "temporal"


# ---------------------------------------------------------------------------
# Core claim dataclass
# ---------------------------------------------------------------------------

@dataclass
class CausalClaim:
    """
    A single extracted causal claim from a policy document.

    Parameters
    ----------
    claim_id : str
        UUID assigned at extraction time for cross-referencing.
    text : str
        The full text of the document paragraph or sentence from which
        the claim was extracted.
    cause_span : str
        The minimal text span expressing the cause element.
    effect_span : str
        The minimal text span expressing the effect element.
    mechanism_span : Optional[str]
        The text span expressing the mediating mechanism, if present.
        None for correlational or definitional claims.
    causal_type : CausalType
        Classified causal relationship type.
    epistemic_status : EpistemicStatus
        Classified evidential standing.
    domain : PolicyDomain
        The policy domain of the source document.
    language : Language
        ISO 639-1 code of the source document language.
    source_char_start : int
        Character offset (inclusive) of the causal span in the source text.
    source_char_end : int
        Character offset (exclusive) of the causal span in the source text.
    extraction_confidence : float
        Model confidence score for the span boundary prediction [0, 1].
    validation_score : Optional[int]
        GPT-4o plausibility score (1–5) from Stage 1 validation.
        None if validation has not been run.
    validation_rationale : Optional[str]
        Free-text rationale from GPT-4o for the plausibility score.
    validation_assumptions : list[str]
        Implicit assumptions identified by the validation model.
    expert_reviewed : bool
        Whether the claim was submitted to human expert validation (Stage 2).
    expert_label : Optional[str]
        Outcome of expert review ('plausible', 'contested', 'implausible').
    flagged_for_review : bool
        True if the claim falls in the borderline triage band (scores 2–4).
    metadata : dict
        Arbitrary extra fields (source document ID, page, section, etc.).

    Notes
    -----
    The triage rule described in Section 4.2 of the paper assigns
    ``flagged_for_review = True`` when ``2 <= validation_score <= 4``,
    reducing expert workload by approximately 60% while maintaining
    validation quality.
    """

    cause_span: str
    effect_span: str
    causal_type: CausalType
    epistemic_status: EpistemicStatus
    domain: PolicyDomain
    language: Language
    source_char_start: int
    source_char_end: int

    claim_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    text: str = ""
    mechanism_span: Optional[str] = None
    extraction_confidence: float = 0.0
    validation_score: Optional[int] = None
    validation_rationale: Optional[str] = None
    validation_assumptions: list = field(default_factory=list)
    expert_reviewed: bool = False
    expert_label: Optional[str] = None
    flagged_for_review: bool = False
    metadata: dict = field(default_factory=dict)

    def __str__(self) -> str:
        mech = f" [via: {self.mechanism_span}]" if self.mechanism_span else ""
        score = f" | plausibility={self.validation_score}/5" if self.validation_score else ""
        return (
            f"[{self.causal_type.value.upper()} / {self.epistemic_status.value}]"
            f" CAUSE: '{self.cause_span}' → EFFECT: '{self.effect_span}'"
            f"{mech}{score}"
        )

    @property
    def is_high_confidence(self) -> bool:
        """True if validation_score is outside the triage band (< 2 or > 4)."""
        if self.validation_score is None:
            return False
        return self.validation_score < 2 or self.validation_score > 4


# ---------------------------------------------------------------------------
# Inconsistency pair dataclass
# ---------------------------------------------------------------------------

@dataclass
class InconsistencyPair:
    """
    A pair of causal claims identified as logically inconsistent.

    Parameters
    ----------
    pair_id : str
        UUID for this inconsistency finding.
    claim_a : CausalClaim
        First claim in the inconsistent pair.
    claim_b : CausalClaim
        Second claim in the inconsistent pair.
    inconsistency_type : InconsistencyType
        Classified inconsistency category.
    llm_resolution : str
        The LLM's determination of whether the apparent inconsistency is
        genuine or represents legitimate contextual variation.
    is_genuine : bool
        True if the LLM (and optionally expert) determined the inconsistency
        to be genuine rather than contextually explained.
    resolution_rationale : str
        Free-text rationale for the is_genuine determination.
    similarity_score : float
        Semantic similarity score between the two claims [0, 1].
    """

    claim_a: CausalClaim
    claim_b: CausalClaim
    inconsistency_type: InconsistencyType
    llm_resolution: str
    is_genuine: bool
    resolution_rationale: str
    similarity_score: float = 0.0
    pair_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    def __str__(self) -> str:
        genuine_str = "GENUINE" if self.is_genuine else "contextual variation"
        return (
            f"[{self.inconsistency_type.value.upper()} inconsistency — {genuine_str}]\n"
            f"  Claim A: {self.claim_a}\n"
            f"  Claim B: {self.claim_b}\n"
            f"  Rationale: {self.resolution_rationale}"
        )


# ---------------------------------------------------------------------------
# Pipeline result container
# ---------------------------------------------------------------------------

@dataclass
class PipelineResult:
    """
    Container for all outputs produced by CausalPolPipeline.run().

    Parameters
    ----------
    document_id : str
        Identifier for the source document.
    domain : PolicyDomain
        Policy domain of the source document.
    language : Language
        Language of the source document.
    claims : list[CausalClaim]
        All extracted causal claims, in document order.
    inconsistency_pairs : list[InconsistencyPair]
        All identified cross-claim inconsistencies.
    n_claims : int
        Total number of extracted claims.
    n_flagged : int
        Number of claims flagged for human expert review.
    n_inconsistencies : int
        Number of confirmed genuine inconsistencies.
    raw_text : str
        The input document text.
    pipeline_version : str
        Version string of the CausalPol package used.
    """

    document_id: str
    domain: PolicyDomain
    language: Language
    claims: list = field(default_factory=list)
    inconsistency_pairs: list = field(default_factory=list)
    raw_text: str = ""
    pipeline_version: str = "0.1.0"

    @property
    def n_claims(self) -> int:
        return len(self.claims)

    @property
    def n_flagged(self) -> int:
        return sum(1 for c in self.claims if c.flagged_for_review)

    @property
    def n_inconsistencies(self) -> int:
        return sum(1 for p in self.inconsistency_pairs if p.is_genuine)

    def summary(self) -> str:
        lines = [
            f"=== CausalPol Pipeline Result ===",
            f"Document ID : {self.document_id}",
            f"Domain      : {self.domain.value}",
            f"Language    : {self.language.value}",
            f"Claims      : {self.n_claims} extracted, {self.n_flagged} flagged",
            f"Inconsist.  : {self.n_inconsistencies} genuine / "
            f"{len(self.inconsistency_pairs)} candidate pairs",
            "",
        ]
        for i, claim in enumerate(self.claims, 1):
            lines.append(f"[{i}] {claim}")
        if self.inconsistency_pairs:
            lines.append("\n--- Inconsistencies ---")
            for pair in self.inconsistency_pairs:
                lines.append(str(pair))
        return "\n".join(lines)
