from causalpol.utils.text import (
    chunk_document,
    count_causal_signals,
    detect_hedge_markers,
    detect_language,
    extract_nominalizations,
    has_causal_signal,
    has_hedge_in_scope,
    normalize_whitespace,
    segment_sentences,
)

__all__ = [
    "chunk_document",
    "count_causal_signals",
    "detect_hedge_markers",
    "detect_language",
    "extract_nominalizations",
    "has_causal_signal",
    "has_hedge_in_scope",
    "normalize_whitespace",
    "segment_sentences",
]
