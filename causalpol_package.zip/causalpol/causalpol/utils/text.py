"""
causalpol.utils.text
====================
Shared text preprocessing utilities used across the CausalPol pipeline.

Functions
---------
detect_language(text)
    Heuristic and library-based language detection returning a Language enum.

normalize_whitespace(text)
    Collapse irregular whitespace in policy document OCR output.

segment_sentences(text, language)
    Language-aware sentence segmentation using spaCy or a lightweight fallback.

extract_nominalizations(text)
    Surface-heuristic nominalization detector for policy causal language.

detect_hedge_markers(text)
    Identify hedge markers and their approximate scope in a text span.

chunk_document(text, max_tokens, overlap)
    Split long documents into overlapping chunks suitable for transformer
    input windows.
"""

from __future__ import annotations

import re
import unicodedata
from typing import Optional

from causalpol.taxonomy.schema import Language


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Common English hedge markers (expanded per Section 4.1 of the paper)
_HEDGE_MARKERS_EN = {
    "may", "might", "could", "can", "would", "should",
    "possibly", "perhaps", "likely", "unlikely", "probably",
    "appears to", "seems to", "tends to", "suggests that",
    "is expected to", "is projected to", "is anticipated to",
    "estimated to", "assumed to", "modelled to",
    "under the assumption", "subject to", "contingent on",
    "if", "provided that", "given that", "assuming that",
    "in the event that", "were to",
}

# Nominalization suffixes commonly found in policy causal language
_NOMINALIZATION_SUFFIXES = (
    "tion", "sion", "ment", "ance", "ence", "ity",
    "ness", "age", "al", "ure", "ing",
)

# Patterns for causal connectives (used to bootstrap extraction heuristics)
_EXPLICIT_CAUSAL_PATTERNS = [
    r"\bbecause\b", r"\bdue to\b", r"\bowing to\b", r"\bas a result of\b",
    r"\bleads? to\b", r"\bresults? in\b", r"\bcauses?\b", r"\bdriven by\b",
    r"\bstemming from\b", r"\barising from\b", r"\battributable to\b",
    r"\bconsequently\b", r"\btherefore\b", r"\bthus\b", r"\bhence\b",
    r"\bso that\b", r"\bin order to\b", r"\bso as to\b",
    r"\bcontributes? to\b", r"\bfacilitates?\b", r"\benables?\b",
    r"\bimpacts?\b", r"\baffects?\b", r"\binfluences?\b",
    r"\binduce[sd]?\b", r"\bgenerate[sd]?\b", r"\bproduce[sd]?\b",
    r"\bpromote[sd]?\b", r"\bprevents?\b", r"\bmitigates?\b",
    r"\breduces?\b", r"\bincreases?\b", r"\bdecreases?\b",
]

_CAUSAL_PATTERN_RE = re.compile(
    "|".join(_EXPLICIT_CAUSAL_PATTERNS), re.IGNORECASE
)


# ---------------------------------------------------------------------------
# Language detection
# ---------------------------------------------------------------------------

def detect_language(text: str) -> Language:
    """
    Detect the language of *text* and return the corresponding Language enum.

    Uses the ``langdetect`` library when available, falling back to a simple
    character n-gram heuristic.  The six supported languages correspond to
    the PolCausal-50K coverage (Section 3.1).

    Parameters
    ----------
    text : str
        Input text (at least a sentence for reliable detection).

    Returns
    -------
    Language
        The detected language.  Defaults to ``Language.ENGLISH`` when
        detection confidence is low or the library is unavailable.
    """
    try:
        from langdetect import detect, DetectorFactory
        DetectorFactory.seed = 42
        code = detect(text[:2000])
        # Map ISO 639-1 codes to Language enum
        _map = {"en": Language.ENGLISH, "fr": Language.FRENCH,
                "de": Language.GERMAN, "es": Language.SPANISH,
                "it": Language.ITALIAN, "pl": Language.POLISH}
        return _map.get(code, Language.ENGLISH)
    except Exception:
        return Language.ENGLISH


# ---------------------------------------------------------------------------
# Text normalization
# ---------------------------------------------------------------------------

def normalize_whitespace(text: str) -> str:
    """
    Normalize whitespace artifacts common in OCR-processed policy PDFs.

    Collapses multiple spaces, normalizes line endings, removes soft hyphens,
    and applies Unicode NFC normalization.

    Parameters
    ----------
    text : str

    Returns
    -------
    str
    """
    # Unicode normalization
    text = unicodedata.normalize("NFC", text)
    # Remove soft hyphens
    text = text.replace("\u00ad", "")
    # Normalize line endings
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Collapse multiple spaces (but not newlines)
    text = re.sub(r" {2,}", " ", text)
    # Remove leading/trailing whitespace per line
    lines = [line.strip() for line in text.splitlines()]
    text = "\n".join(lines)
    return text.strip()


# ---------------------------------------------------------------------------
# Sentence segmentation
# ---------------------------------------------------------------------------

def segment_sentences(text: str, language: Language = Language.ENGLISH) -> list[str]:
    """
    Segment *text* into sentences using spaCy when available, otherwise a
    rule-based fallback.

    Parameters
    ----------
    text : str
        Input text.
    language : Language
        Source language (used to select the spaCy model).

    Returns
    -------
    list[str]
        List of sentence strings.
    """
    _spacy_models = {
        Language.ENGLISH: "en_core_web_sm",
        Language.FRENCH: "fr_core_news_sm",
        Language.GERMAN: "de_core_news_sm",
        Language.SPANISH: "es_core_news_sm",
        Language.ITALIAN: "it_core_news_sm",
        Language.POLISH: "pl_core_news_sm",
    }
    try:
        import spacy
        model_name = _spacy_models.get(language, "en_core_web_sm")
        try:
            nlp = spacy.load(model_name, disable=["ner", "tagger", "parser",
                                                   "attribute_ruler", "lemmatizer"])
            nlp.add_pipe("sentencizer")
        except OSError:
            nlp = spacy.blank(language.value)
            nlp.add_pipe("sentencizer")
        doc = nlp(text)
        return [sent.text.strip() for sent in doc.sents if sent.text.strip()]
    except ImportError:
        pass

    # Rule-based fallback: split on sentence-ending punctuation
    sentences = re.split(r'(?<=[.!?])\s+(?=[A-Z\u00C0-\u024F])', text)
    return [s.strip() for s in sentences if s.strip()]


# ---------------------------------------------------------------------------
# Nominalization detection
# ---------------------------------------------------------------------------

def extract_nominalizations(text: str) -> list[dict]:
    """
    Identify nominalized verb phrases in *text* that commonly carry causal
    meaning in policy documents.

    This implements the heuristic nominalization detector described in
    Section 4.1 of the paper.  It detects multi-word noun phrases formed
    from deverbal nouns (nominalizations) combined with causal prepositions
    such as *stemming from*, *resulting in*, *due to*, etc.

    Parameters
    ----------
    text : str

    Returns
    -------
    list[dict]
        Each dict has keys: ``span`` (str), ``start`` (int), ``end`` (int),
        ``pattern`` (str), ``nominalization`` (str).

    Examples
    --------
    >>> extract_nominalizations(
    ...     "The reduction in employment stemming from automation is projected to..."
    ... )
    [{'span': 'reduction in employment stemming from automation',
      'start': 4, 'end': 52,
      'pattern': 'nominalization + causal_prep',
      'nominalization': 'reduction'}]
    """
    _causal_preps = [
        r"stemming from", r"resulting (?:in|from)", r"arising from",
        r"attributable to", r"due to", r"owing to", r"caused by",
        r"leading to", r"contributing to", r"driven by",
    ]
    findings = []
    for prep_pat in _causal_preps:
        for m in re.finditer(prep_pat, text, re.IGNORECASE):
            # Look back up to 10 words for a nominal head
            preceding = text[max(0, m.start() - 80) : m.start()]
            words = preceding.split()[-10:]
            for word in reversed(words):
                w = word.strip(".,;:()")
                if any(w.lower().endswith(suf) for suf in _NOMINALIZATION_SUFFIXES):
                    # Extend span to include a short following phrase
                    end_pos = min(len(text), m.end() + 60)
                    span_text = text[m.start() - len(" ".join(words)) - 1 : end_pos]
                    findings.append({
                        "span": span_text.strip(),
                        "start": m.start() - len(" ".join(words)) - 1,
                        "end": end_pos,
                        "pattern": "nominalization + causal_prep",
                        "nominalization": w,
                    })
                    break
    return findings


# ---------------------------------------------------------------------------
# Hedge detection
# ---------------------------------------------------------------------------

def detect_hedge_markers(text: str, language: Language = Language.ENGLISH) -> list[dict]:
    """
    Identify hedge markers in *text* and return their positions.

    Used by the hedge scope parser component of CausalPol (Section 4.1) to
    tag causal claims within hedge scope with an appropriate epistemic status
    feature before classification.

    Parameters
    ----------
    text : str
    language : Language
        Currently English markers are fully implemented; other languages
        use a reduced set of modal verbs.

    Returns
    -------
    list[dict]
        Each dict has keys: ``marker`` (str), ``start`` (int), ``end`` (int).
    """
    markers_to_use = _HEDGE_MARKERS_EN  # TODO: add per-language marker sets
    findings = []
    for marker in markers_to_use:
        pattern = re.compile(r"\b" + re.escape(marker) + r"\b", re.IGNORECASE)
        for m in pattern.finditer(text):
            findings.append({
                "marker": m.group(0),
                "start": m.start(),
                "end": m.end(),
            })
    # Sort by position
    findings.sort(key=lambda x: x["start"])
    return findings


def has_hedge_in_scope(text: str, span_start: int, span_end: int,
                       language: Language = Language.ENGLISH,
                       window: int = 50) -> bool:
    """
    Return True if a hedge marker appears within *window* characters before
    or within the causal span defined by [span_start, span_end).

    Parameters
    ----------
    text : str
    span_start : int
    span_end : int
    language : Language
    window : int
        Number of characters before span_start to search for hedge markers.
    """
    search_start = max(0, span_start - window)
    search_text = text[search_start:span_end]
    markers = detect_hedge_markers(search_text, language)
    return len(markers) > 0


# ---------------------------------------------------------------------------
# Explicit causal signal detection (heuristic, used for preprocessing)
# ---------------------------------------------------------------------------

def has_causal_signal(text: str) -> bool:
    """
    Return True if *text* contains at least one explicit causal connective.

    This is used as a fast pre-filter before running the full extraction
    model, substantially reducing inference cost on non-causal paragraphs.

    Parameters
    ----------
    text : str

    Returns
    -------
    bool
    """
    return bool(_CAUSAL_PATTERN_RE.search(text))


def count_causal_signals(text: str) -> int:
    """Return the number of explicit causal connective matches in *text*."""
    return len(_CAUSAL_PATTERN_RE.findall(text))


# ---------------------------------------------------------------------------
# Document chunking
# ---------------------------------------------------------------------------

def chunk_document(
    text: str,
    max_tokens: int = 400,
    overlap_tokens: int = 50,
    chars_per_token: float = 4.5,
) -> list[dict]:
    """
    Split *text* into overlapping chunks for transformer input windows.

    The chunking strategy preserves sentence boundaries where possible,
    using the rule-based sentence splitter as a fallback.

    Parameters
    ----------
    text : str
        Full document text (after normalization).
    max_tokens : int
        Approximate maximum number of tokens per chunk.
    overlap_tokens : int
        Approximate overlap between consecutive chunks (for context
        continuity across chunk boundaries).
    chars_per_token : float
        Estimated characters per token (default 4.5, suitable for English
        and most European languages with mDeBERTa tokenization).

    Returns
    -------
    list[dict]
        Each dict has keys: ``text`` (str), ``char_start`` (int),
        ``char_end`` (int), ``chunk_index`` (int).
    """
    max_chars = int(max_tokens * chars_per_token)
    overlap_chars = int(overlap_tokens * chars_per_token)

    sentences = segment_sentences(text)
    chunks = []
    current_chunk: list[str] = []
    current_len = 0
    char_offset = 0
    chunk_index = 0

    for sent in sentences:
        sent_len = len(sent) + 1  # +1 for space
        if current_len + sent_len > max_chars and current_chunk:
            chunk_text = " ".join(current_chunk)
            chunks.append({
                "text": chunk_text,
                "char_start": char_offset,
                "char_end": char_offset + len(chunk_text),
                "chunk_index": chunk_index,
            })
            chunk_index += 1
            # Overlap: keep last sentences that fit in overlap window
            overlap: list[str] = []
            overlap_len = 0
            for s in reversed(current_chunk):
                if overlap_len + len(s) > overlap_chars:
                    break
                overlap.insert(0, s)
                overlap_len += len(s) + 1
            char_offset += len(chunk_text) - overlap_len
            current_chunk = overlap
            current_len = overlap_len

        current_chunk.append(sent)
        current_len += sent_len

    if current_chunk:
        chunk_text = " ".join(current_chunk)
        chunks.append({
            "text": chunk_text,
            "char_start": char_offset,
            "char_end": char_offset + len(chunk_text),
            "chunk_index": chunk_index,
        })

    return chunks
