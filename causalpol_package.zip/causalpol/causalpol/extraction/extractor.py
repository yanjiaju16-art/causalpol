"""
causalpol.extraction.extractor
==============================
Causal span extraction using a fine-tuned mDeBERTa-v3-base model.

This module implements the token-level sequence labeling approach described
in Section 4.1 of the paper, with three policy-specific augmentations:

1. **Nominalization detection** — pre-processing pass to identify and mark
   nominalized verb phrases before tokenization.
2. **Hedge scope parsing** — epistemic status features derived from hedge
   marker detection are prepended to candidate spans.
3. **Domain terminology encoding** — the domain label is prepended to the
   model input to condition extraction on domain vocabulary.

The BIO tagging scheme uses six tags::

    B-CAUSE, I-CAUSE   — cause span tokens
    B-EFFECT, I-EFFECT — effect span tokens
    B-MECH, I-MECH     — mechanism span tokens
    O                  — outside any causal span

Classes
-------
CausalSpanExtractor
    Wraps the fine-tuned mDeBERTa-v3-base model for inference.  Falls back
    to a rule-based heuristic extractor when the model weights are not
    available (useful for testing and research prototyping without GPU).

RuleBasedExtractor
    Heuristic extraction baseline using dependency parsing and causal
    connective matching.  Serves as a reproducible lower bound and as the
    extraction backend when transformer weights are unavailable.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Optional

from causalpol.taxonomy.schema import (
    CausalClaim, CausalType, EpistemicStatus, Language, PolicyDomain
)
from causalpol.utils.text import (
    chunk_document, detect_hedge_markers, extract_nominalizations,
    has_causal_signal, has_hedge_in_scope, normalize_whitespace,
    segment_sentences,
)

logger = logging.getLogger(__name__)

# Default HuggingFace model path (to be replaced with the fine-tuned checkpoint)
_DEFAULT_MODEL = "microsoft/mdeberta-v3-base"

# BIO tag set
BIO_TAGS = ["O", "B-CAUSE", "I-CAUSE", "B-EFFECT", "I-EFFECT", "B-MECH", "I-MECH"]
TAG2ID = {t: i for i, t in enumerate(BIO_TAGS)}
ID2TAG = {i: t for t, i in TAG2ID.items()}


# ---------------------------------------------------------------------------
# Rule-based extractor (baseline / fallback)
# ---------------------------------------------------------------------------

class RuleBasedExtractor:
    """
    Heuristic causal span extractor using explicit connectives and
    nominalization patterns.

    This reproduces the surface-level baseline approach against which
    CausalPol's neural model is compared.  It is useful for:

    * Rapid prototyping without GPU access.
    * Lower-bound performance benchmarking.
    * Generating silver-standard annotations for new domains.

    Parameters
    ----------
    domain : PolicyDomain
        Policy domain — used to weight domain-specific connective patterns.
    language : Language
        Source language.

    Notes
    -----
    Performance on the PolCausal-50K test set:
    Overall F1 ≈ 0.49 (substantially below the 0.71 prior best neural
    system and the 0.79 CausalPol result).
    """

    _CONNECTIVE_TO_STRUCTURE = {
        # Pattern: (cause_side, effect_side)
        # 'L' = left of connective, 'R' = right of connective
        "because": ("R", "L"),
        "due to": ("R", "L"),
        "owing to": ("R", "L"),
        "as a result of": ("R", "L"),
        "stemming from": ("R", "L"),
        "arising from": ("R", "L"),
        "attributable to": ("R", "L"),
        "leads to": ("L", "R"),
        "results in": ("L", "R"),
        "causes": ("L", "R"),
        "driven by": ("R", "L"),
        "contributes to": ("L", "R"),
        "consequently": ("L", "R"),
        "therefore": ("L", "R"),
        "thus": ("L", "R"),
        "hence": ("L", "R"),
    }

    def __init__(self, domain: PolicyDomain, language: Language):
        self.domain = domain
        self.language = language

    def extract(self, text: str) -> list[dict]:
        """
        Extract causal spans from *text* using surface patterns.

        Parameters
        ----------
        text : str
            A sentence or short paragraph.

        Returns
        -------
        list[dict]
            Each dict has keys matching CausalClaim fields:
            ``cause_span``, ``effect_span``, ``mechanism_span`` (None),
            ``source_char_start``, ``source_char_end``,
            ``extraction_confidence``.
        """
        results = []
        for connective, (cause_side, effect_side) in self._CONNECTIVE_TO_STRUCTURE.items():
            pattern = re.compile(r"\b" + re.escape(connective) + r"\b", re.IGNORECASE)
            for m in pattern.finditer(text):
                left = text[: m.start()].strip()
                right = text[m.end() :].strip()
                # Truncate to nearest sentence boundary
                left_trunc = re.split(r"[.!?;]", left)[-1].strip()
                right_trunc = re.split(r"[.!?;]", right)[0].strip()
                if not left_trunc or not right_trunc:
                    continue
                cause = left_trunc if cause_side == "L" else right_trunc
                effect = right_trunc if effect_side == "R" else left_trunc
                results.append({
                    "cause_span": cause,
                    "effect_span": effect,
                    "mechanism_span": None,
                    "source_char_start": m.start(),
                    "source_char_end": m.end(),
                    "extraction_confidence": 0.45,  # fixed heuristic confidence
                    "connective": connective,
                })
        # Also check nominalization patterns
        for nom in extract_nominalizations(text):
            results.append({
                "cause_span": nom.get("nominalization", ""),
                "effect_span": nom.get("span", ""),
                "mechanism_span": None,
                "source_char_start": nom["start"],
                "source_char_end": nom["end"],
                "extraction_confidence": 0.35,
                "connective": "nominalization",
            })
        return results


# ---------------------------------------------------------------------------
# Neural extractor
# ---------------------------------------------------------------------------

class CausalSpanExtractor:
    """
    Neural causal span extractor built on fine-tuned mDeBERTa-v3-base.

    Implements the three-stage extraction pipeline from Section 4.1:

    1. **Pre-processing** — normalization, nominalization marking, hedge
       detection, domain prefix injection.
    2. **Model inference** — token-level BIO tagging with mDeBERTa-v3.
    3. **Post-processing** — BIO span assembly, confidence scoring,
       duplicate/overlap resolution.

    Parameters
    ----------
    model_name_or_path : str
        HuggingFace model identifier or local path to a fine-tuned checkpoint.
        When the fine-tuned PolCausal-50K checkpoint is released, pass its
        path here.  The default is the base mDeBERTa-v3 model, which
        requires fine-tuning before meaningful extraction.
    domain : PolicyDomain
        Policy domain — prepended to each input to activate domain-adaptive
        masking learned during fine-tuning.
    language : Language
        Source language.
    device : str
        PyTorch device string (``"cpu"``, ``"cuda"``, ``"cuda:0"``).
    use_rule_based_fallback : bool
        If True (default), fall back to RuleBasedExtractor when the
        transformers library is not installed or model loading fails.
    confidence_threshold : float
        Minimum per-token confidence to include a BIO span in output.
        Lower values increase recall at the cost of precision.

    Examples
    --------
    >>> extractor = CausalSpanExtractor(
    ...     model_name_or_path="path/to/causalpol-mdeberta-v3",
    ...     domain=PolicyDomain.MONETARY_POLICY,
    ...     language=Language.ENGLISH,
    ... )
    >>> claims = extractor.extract_from_text(
    ...     "Higher interest rates reduce inflation through demand contraction."
    ... )
    >>> print(claims[0].cause_span)
    'Higher interest rates'
    """

    def __init__(
        self,
        model_name_or_path: str = _DEFAULT_MODEL,
        domain: PolicyDomain = PolicyDomain.MONETARY_POLICY,
        language: Language = Language.ENGLISH,
        device: str = "cpu",
        use_rule_based_fallback: bool = True,
        confidence_threshold: float = 0.5,
    ):
        self.model_name_or_path = model_name_or_path
        self.domain = domain
        self.language = language
        self.device = device
        self.use_rule_based_fallback = use_rule_based_fallback
        self.confidence_threshold = confidence_threshold

        self._model = None
        self._tokenizer = None
        self._fallback = RuleBasedExtractor(domain, language)
        self._model_loaded = False

        self._try_load_model()

    def _try_load_model(self) -> None:
        """Attempt to load the fine-tuned model; set fallback flag on failure."""
        try:
            from transformers import AutoTokenizer, AutoModelForTokenClassification
            import torch

            logger.info(f"Loading model from: {self.model_name_or_path}")
            self._tokenizer = AutoTokenizer.from_pretrained(self.model_name_or_path)
            self._model = AutoModelForTokenClassification.from_pretrained(
                self.model_name_or_path,
                num_labels=len(BIO_TAGS),
                ignore_mismatched_sizes=True,
            )
            self._model.to(self.device)
            self._model.eval()
            self._model_loaded = True
            logger.info("Model loaded successfully.")
        except Exception as exc:
            logger.warning(
                f"Could not load transformer model ({exc}). "
                "Using rule-based fallback extractor."
            )
            self._model_loaded = False

    def _build_input(self, text: str) -> str:
        """
        Prepend the domain label as a context prefix (domain terminology
        encoder mechanism from Section 4.1).
        """
        domain_prefix = f"[DOMAIN: {self.domain.value.upper()}] "
        return domain_prefix + text

    def _infer_bio_tags(self, text: str) -> list[dict]:
        """
        Run BIO tagging inference on a single text chunk.

        Returns a list of token-level dicts with keys:
        ``token``, ``tag``, ``score``, ``start``, ``end``.
        """
        import torch

        inputs = self._tokenizer(
            self._build_input(text),
            return_tensors="pt",
            truncation=True,
            max_length=512,
            return_offsets_mapping=True,
        )
        offset_mapping = inputs.pop("offset_mapping")[0].tolist()
        inputs = {k: v.to(self.device) for k, v in inputs.items()}

        with torch.no_grad():
            outputs = self._model(**inputs)

        logits = outputs.logits[0]
        probs = torch.softmax(logits, dim=-1)
        tag_ids = logits.argmax(dim=-1).tolist()
        confidences = probs.max(dim=-1).values.tolist()

        token_tags = []
        for idx, (tag_id, conf, offsets) in enumerate(
            zip(tag_ids, confidences, offset_mapping)
        ):
            # Skip special tokens (offset (0,0))
            if offsets[0] == 0 and offsets[1] == 0:
                continue
            token_tags.append({
                "token": self._tokenizer.convert_ids_to_tokens([inputs["input_ids"][0][idx]])[0],
                "tag": ID2TAG[tag_id],
                "score": conf,
                "start": offsets[0],
                "end": offsets[1],
            })
        return token_tags

    def _assemble_spans(self, token_tags: list[dict], source_offset: int = 0) -> list[dict]:
        """
        Convert BIO token-level tags into span-level extractions.

        Parameters
        ----------
        token_tags : list[dict]
        source_offset : int
            Character offset of the chunk within the full document.

        Returns
        -------
        list[dict]
            Dicts with keys: ``span_type``, ``text``, ``start``, ``end``,
            ``confidence``.
        """
        spans = []
        current_tag = None
        current_tokens = []
        current_scores = []
        span_start = 0

        for tok in token_tags:
            tag = tok["tag"]
            prefix = tag.split("-")[0] if "-" in tag else "O"
            label = tag.split("-")[1] if "-" in tag else None

            if prefix == "B":
                if current_tag and current_tokens:
                    spans.append({
                        "span_type": current_tag,
                        "text": " ".join(current_tokens),
                        "start": span_start + source_offset,
                        "end": tok["start"] + source_offset,
                        "confidence": sum(current_scores) / len(current_scores),
                    })
                current_tag = label
                current_tokens = [tok["token"].replace("▁", "")]
                current_scores = [tok["score"]]
                span_start = tok["start"]
            elif prefix == "I" and label == current_tag:
                current_tokens.append(tok["token"].replace("▁", ""))
                current_scores.append(tok["score"])
            else:
                if current_tag and current_tokens:
                    spans.append({
                        "span_type": current_tag,
                        "text": " ".join(current_tokens),
                        "start": span_start + source_offset,
                        "end": tok["start"] + source_offset,
                        "confidence": sum(current_scores) / len(current_scores),
                    })
                current_tag = None
                current_tokens = []
                current_scores = []

        if current_tag and current_tokens:
            spans.append({
                "span_type": current_tag,
                "text": " ".join(current_tokens),
                "start": span_start + source_offset,
                "end": span_start + len(" ".join(current_tokens)) + source_offset,
                "confidence": sum(current_scores) / len(current_scores),
            })

        return [s for s in spans if s["confidence"] >= self.confidence_threshold]

    def _spans_to_claims(
        self, spans: list[dict], source_text: str, chunk_offset: int = 0
    ) -> list[CausalClaim]:
        """
        Pair CAUSE and EFFECT spans (with optional MECH) into CausalClaim objects.
        """
        causes = [s for s in spans if s["span_type"] == "CAUSE"]
        effects = [s for s in spans if s["span_type"] == "EFFECT"]
        mechs = [s for s in spans if s["span_type"] == "MECH"]

        claims = []
        # Greedy nearest-neighbor pairing
        used_effects = set()
        used_mechs = set()

        for cause in causes:
            if not effects:
                break
            # Find nearest effect (by character distance)
            best_effect = min(
                [e for i, e in enumerate(effects) if i not in used_effects],
                key=lambda e: abs(e["start"] - cause["end"]),
                default=None,
            )
            if best_effect is None:
                continue
            effect_idx = effects.index(best_effect)
            used_effects.add(effect_idx)

            # Find mechanism between cause and effect, if any
            mech_span = None
            for i, mech in enumerate(mechs):
                if i in used_mechs:
                    continue
                if cause["end"] <= mech["start"] <= best_effect["start"]:
                    mech_span = mech["text"]
                    used_mechs.add(i)
                    break

            # Determine epistemic status from hedge detection
            claim_start = min(cause["start"], best_effect["start"])
            claim_end = max(cause["end"], best_effect["end"])
            in_hedge = has_hedge_in_scope(
                source_text, claim_start, claim_end, self.language
            )
            epistemic = EpistemicStatus.SPECULATIVE if in_hedge else EpistemicStatus.ESTABLISHED

            # Causal type heuristic (overridden by validation pipeline if run)
            causal_type = (
                CausalType.MECHANISTIC if mech_span else CausalType.CORRELATIONAL
            )

            conf = (cause["confidence"] + best_effect["confidence"]) / 2
            claims.append(CausalClaim(
                cause_span=cause["text"],
                effect_span=best_effect["text"],
                mechanism_span=mech_span,
                causal_type=causal_type,
                epistemic_status=epistemic,
                domain=self.domain,
                language=self.language,
                source_char_start=claim_start + chunk_offset,
                source_char_end=claim_end + chunk_offset,
                extraction_confidence=conf,
                text=source_text,
            ))

        return claims

    def extract_from_text(self, text: str) -> list[CausalClaim]:
        """
        Extract causal claims from *text*.

        Applies pre-processing, chunks the document, runs inference (or the
        rule-based fallback), and assembles CausalClaim objects.

        Parameters
        ----------
        text : str
            Raw policy document text (any length).

        Returns
        -------
        list[CausalClaim]
            Extracted claims, in document order.
        """
        text = normalize_whitespace(text)

        # Fast pre-filter: skip paragraphs with no causal signal
        if not has_causal_signal(text):
            logger.debug("No causal signals detected; skipping extraction.")
            return []

        if not self._model_loaded or not self.use_rule_based_fallback is False:
            if not self._model_loaded:
                return self._extract_rule_based(text)

        chunks = chunk_document(text)
        all_claims: list[CausalClaim] = []

        for chunk in chunks:
            chunk_text = chunk["text"]
            chunk_offset = chunk["char_start"]
            try:
                token_tags = self._infer_bio_tags(chunk_text)
                spans = self._assemble_spans(token_tags, source_offset=chunk_offset)
                claims = self._spans_to_claims(spans, chunk_text, chunk_offset)
                all_claims.extend(claims)
            except Exception as exc:
                logger.warning(
                    f"Inference failed on chunk {chunk['chunk_index']}: {exc}. "
                    "Falling back to rule-based for this chunk."
                )
                all_claims.extend(self._extract_rule_based(chunk_text, chunk_offset))

        # Deduplicate overlapping spans
        all_claims = self._deduplicate(all_claims)
        return all_claims

    def _extract_rule_based(self, text: str, offset: int = 0) -> list[CausalClaim]:
        """Apply RuleBasedExtractor and convert output to CausalClaim objects."""
        raw = self._fallback.extract(text)
        claims = []
        for r in raw:
            if not r["cause_span"] or not r["effect_span"]:
                continue
            in_hedge = has_hedge_in_scope(
                text, r["source_char_start"], r["source_char_end"], self.language
            )
            epistemic = EpistemicStatus.SPECULATIVE if in_hedge else EpistemicStatus.ESTABLISHED
            causal_type = CausalType.MECHANISTIC if r["mechanism_span"] else CausalType.CORRELATIONAL
            claims.append(CausalClaim(
                cause_span=r["cause_span"],
                effect_span=r["effect_span"],
                mechanism_span=r["mechanism_span"],
                causal_type=causal_type,
                epistemic_status=epistemic,
                domain=self.domain,
                language=self.language,
                source_char_start=r["source_char_start"] + offset,
                source_char_end=r["source_char_end"] + offset,
                extraction_confidence=r["extraction_confidence"],
                text=text,
            ))
        return claims

    @staticmethod
    def _deduplicate(claims: list[CausalClaim]) -> list[CausalClaim]:
        """
        Remove duplicate claims with overlapping spans, keeping the one with
        higher extraction confidence.
        """
        if not claims:
            return claims
        claims_sorted = sorted(claims, key=lambda c: c.extraction_confidence, reverse=True)
        kept: list[CausalClaim] = []
        for candidate in claims_sorted:
            overlaps = False
            for existing in kept:
                # Check for cause span overlap
                if (candidate.source_char_start < existing.source_char_end and
                        candidate.source_char_end > existing.source_char_start):
                    overlaps = True
                    break
            if not overlaps:
                kept.append(candidate)
        return sorted(kept, key=lambda c: c.source_char_start)
