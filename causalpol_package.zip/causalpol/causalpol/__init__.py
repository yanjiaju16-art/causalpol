"""
CausalPol: Extracting and Validating Causal Claims in Policy Documents
======================================================================

CausalPol is a modular NLP system for extracting, classifying, validating,
and detecting inconsistencies in causal claims embedded in multilingual
policy documents.

The system implements the three-stage pipeline described in:

    CausalPol: Extracting and Validating Causal Claims in Policy Documents
    Using Large Language Models (Anonymous, under review)

Modules
-------
causalpol.extraction
    Causal span extraction using fine-tuned mDeBERTa-v3 with policy-specific
    nominalization detection and hedge-scope parsing.

causalpol.validation
    LLM-based claim validation pipeline (GPT-4o) with uncertainty-aware
    triage to domain expert review.

causalpol.consistency
    Cross-claim inconsistency detection: pairwise semantic similarity with
    directional opposition resolution.

causalpol.taxonomy
    Causal type and epistemic status taxonomy definitions and utilities.

causalpol.utils
    Shared preprocessing, language detection, and formatting utilities.

Quick Start
-----------
>>> from causalpol import CausalPolPipeline
>>> pipeline = CausalPolPipeline(openai_api_key="sk-...")
>>> doc = "Higher interest rates reduce inflation through demand contraction, "
...       "but supply constraints cause inflation independent of demand conditions."
>>> result = pipeline.run(doc, domain="monetary_policy", language="en")
>>> for claim in result.claims:
...     print(claim)
"""

from causalpol.pipeline import CausalPolPipeline
from causalpol.taxonomy.schema import (
    CausalClaim,
    CausalType,
    EpistemicStatus,
    PolicyDomain,
    Language,
    InconsistencyType,
    InconsistencyPair,
    PipelineResult,
)

__version__ = "0.1.0"
__author__ = "CausalPol Contributors"
__license__ = "Apache-2.0"

__all__ = [
    "CausalPolPipeline",
    "CausalClaim",
    "CausalType",
    "EpistemicStatus",
    "PolicyDomain",
    "Language",
    "InconsistencyType",
    "InconsistencyPair",
    "PipelineResult",
]
