"""
causalpol.validation.validator
==============================
LLM-based causal claim validation pipeline (Section 4.2 of the paper).

The pipeline implements a two-stage process:

**Stage 1 — GPT-4o Plausibility Assessment**
    Each extracted CausalClaim is formatted as a structured proposition and
    submitted to GPT-4o with a domain-specific validation prompt.  The model
    returns a plausibility score (1–5), a rationale, identified implicit
    assumptions, and a flag for borderline claims.

**Stage 2 — Uncertainty-Aware Triage**
    Claims with scores < 2 or > 4 are treated as reliable without further
    review.  Only borderline claims (2 ≤ score ≤ 4) are submitted for human
    expert validation.  This triage reduces expert workload by approximately
    60% while maintaining validation quality (Section 4.2).

The module also reproduces the key finding from Section 6.1: GPT-4o
systematically over-rates mechanistically familiar claims regardless of
whether the mechanism applies in the specific context.  Researchers should
be aware of this bias when interpreting validation scores.

Classes
-------
ClaimValidator
    Main entry point for claim validation.  Accepts a list of CausalClaim
    objects and returns them with validation_score, validation_rationale,
    validation_assumptions, and flagged_for_review fields populated.

PromptBuilder
    Constructs domain-specific validation prompts.

ValidationResult
    Lightweight dataclass for structured GPT-4o JSON responses.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from typing import Optional

from causalpol.taxonomy.schema import (
    CausalClaim, CausalType, EpistemicStatus, PolicyDomain
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Prompt builder
# ---------------------------------------------------------------------------

_DOMAIN_CONTEXTS = {
    PolicyDomain.MONETARY_POLICY: (
        "monetary economics, central banking, and macroeconomic stabilization policy. "
        "Relevant considerations include: monetary transmission mechanisms, the zero lower "
        "bound, supply-side vs. demand-side inflation, expectations anchoring, and the "
        "limits of interest rate policy under structural supply constraints."
    ),
    PolicyDomain.FISCAL_POLICY: (
        "fiscal policy, public finance, and macroeconomic stabilization. "
        "Relevant considerations include: fiscal multipliers, crowding-out effects, "
        "automatic stabilizers, debt sustainability, and distributional incidence."
    ),
    PolicyDomain.PHARMACEUTICAL_REGULATION: (
        "pharmaceutical regulation, drug safety, and health technology assessment. "
        "Relevant considerations include: evidence standards for efficacy and safety, "
        "benefit-risk balancing, post-marketing surveillance, and regulatory science."
    ),
    PolicyDomain.ENVIRONMENTAL_REGULATION: (
        "environmental regulation, climate policy, and ecological economics. "
        "Relevant considerations include: carbon pricing mechanisms, technology mandates, "
        "general equilibrium rebound effects, and transboundary externalities."
    ),
    PolicyDomain.LABOR_MARKET_POLICY: (
        "labor economics, employment policy, and industrial relations. "
        "Relevant considerations include: wage-employment tradeoffs, minimum wage effects, "
        "labor market monopsony, skills mismatch, and heterogeneous worker effects."
    ),
    PolicyDomain.TRADE_POLICY: (
        "international trade, trade policy, and economic integration. "
        "Relevant considerations include: comparative advantage, terms-of-trade effects, "
        "trade adjustment costs, global value chain effects, and non-tariff barriers."
    ),
    PolicyDomain.TECHNOLOGY_REGULATION: (
        "technology regulation, digital markets, and platform economics. "
        "Relevant considerations include: network effects, multi-sided market dynamics, "
        "algorithmic accountability, privacy-innovation tradeoffs, and regulatory capture."
    ),
}

_SYSTEM_PROMPT = """You are an expert policy analyst and domain scientist serving as a
causal claim validator for the CausalPol system. Your task is to assess the plausibility
of causal claims extracted from policy documents.

For each claim, you will evaluate:
1. Mechanistic plausibility — does a credible causal mechanism connect cause to effect?
2. Consistency with established domain knowledge — is this claim supported by the
   scientific literature in the relevant field?
3. Contextual applicability — even if the mechanism is generally valid, does it apply
   in the specific context described in the document?
4. Implicit assumptions — what unstated premises must be true for the claim to hold?

CRITICAL BIAS WARNING: Avoid rating claims as highly plausible solely because they
invoke a widely cited mechanism (e.g., "higher interest rates reduce inflation through
demand contraction"). Always assess whether the mechanism applies in the specific
context — extreme price rigidities, zero lower bound environments, supply-side
inflation, and other structural conditions may invalidate standard mechanisms.

Respond ONLY with a valid JSON object (no markdown, no preamble) with this schema:
{
  "plausibility_score": <integer 1-5>,
  "score_rationale": "<string: 2-3 sentence explanation>",
  "mechanism_assessment": "<string: is the causal mechanism plausible?>",
  "domain_knowledge_assessment": "<string: is the claim consistent with established evidence?>",
  "contextual_applicability": "<string: does this mechanism apply in this specific context?>",
  "implicit_assumptions": ["<assumption 1>", "<assumption 2>", ...],
  "contested_in_literature": <boolean>,
  "flag_for_expert_review": <boolean>,
  "failure_modes": ["<potential failure mode 1>", ...]
}

Plausibility score rubric:
  5 = Well-established, robust causal mechanism with strong empirical support
  4 = Plausible mechanism with moderate empirical support; minor caveats
  3 = Mechanistically possible but contested, context-dependent, or weakly supported
  2 = Questionable mechanism; significant empirical counter-evidence or logical issues
  1 = Implausible or logically inconsistent; contradicts established domain knowledge
"""


class PromptBuilder:
    """
    Constructs domain-specific validation prompts for CausalClaim objects.

    Parameters
    ----------
    domain : PolicyDomain
    """

    def __init__(self, domain: PolicyDomain):
        self.domain = domain
        self._domain_context = _DOMAIN_CONTEXTS.get(
            domain,
            "policy analysis and evidence-based policymaking."
        )

    def build(self, claim: CausalClaim) -> str:
        """
        Build the user-turn validation prompt for *claim*.

        Parameters
        ----------
        claim : CausalClaim

        Returns
        -------
        str
            The formatted prompt string.
        """
        mech_line = (
            f"  Mechanism (if specified): {claim.mechanism_span}"
            if claim.mechanism_span
            else "  Mechanism: not specified in document"
        )
        return f"""Please validate the following causal claim extracted from a policy document.

DOMAIN CONTEXT: {self._domain_context}

EXTRACTED CAUSAL CLAIM:
  Causal type: {claim.causal_type.value}
  Epistemic status (as marked in document): {claim.epistemic_status.value}
  Cause: {claim.cause_span}
  Effect: {claim.effect_span}
{mech_line}

SURROUNDING TEXT:
{claim.text[:600] if claim.text else "[not provided]"}

Assess this claim according to the validation rubric. Remember to evaluate contextual
applicability carefully — do not over-attribute plausibility based solely on the
familiarity of the causal mechanism."""


# ---------------------------------------------------------------------------
# Validation result dataclass
# ---------------------------------------------------------------------------

@dataclass
class ValidationResult:
    """Structured output from a single GPT-4o validation call."""
    plausibility_score: int = 3
    score_rationale: str = ""
    mechanism_assessment: str = ""
    domain_knowledge_assessment: str = ""
    contextual_applicability: str = ""
    implicit_assumptions: list = field(default_factory=list)
    contested_in_literature: bool = False
    flag_for_expert_review: bool = False
    failure_modes: list = field(default_factory=list)
    raw_response: str = ""
    parse_error: bool = False


# ---------------------------------------------------------------------------
# Main validator
# ---------------------------------------------------------------------------

class ClaimValidator:
    """
    LLM-based causal claim validator (Section 4.2 of the paper).

    Uses GPT-4o to assess the plausibility of extracted causal claims and
    applies an uncertainty-aware triage to prioritize human expert review.

    Parameters
    ----------
    openai_api_key : str
        OpenAI API key with access to GPT-4o.
    domain : PolicyDomain
        Policy domain for context-specific prompting.
    triage_low : int
        Lower triage threshold.  Claims with score ≤ triage_low are treated
        as reliably implausible without expert review.  Default: 2.
    triage_high : int
        Upper triage threshold.  Claims with score ≥ triage_high are treated
        as reliably plausible without expert review.  Default: 4.
    model : str
        OpenAI model name.  Default: ``"gpt-4o"``.
    max_retries : int
        Number of API call retries on transient failures.
    retry_delay : float
        Seconds to wait between retries.
    batch_size : int
        Number of claims to validate before sleeping (rate limit management).

    Notes
    -----
    The triage band [2, 4] is the operationally critical zone identified in
    Section 4.2.  The false negative rate (contested claims rated plausible
    by GPT-4o) is 11.3%; the false positive rate is 16.7% (Section 6.1).

    The systematic LLM bias documented in Section 6.1 — over-rating
    mechanistically familiar claims regardless of contextual applicability —
    is addressed in the validation prompt via an explicit CRITICAL BIAS
    WARNING.  Researchers should monitor this failure mode in new domains.
    """

    def __init__(
        self,
        openai_api_key: str,
        domain: PolicyDomain = PolicyDomain.MONETARY_POLICY,
        triage_low: int = 2,
        triage_high: int = 4,
        model: str = "gpt-4o",
        max_retries: int = 3,
        retry_delay: float = 2.0,
        batch_size: int = 10,
    ):
        self.openai_api_key = openai_api_key
        self.domain = domain
        self.triage_low = triage_low
        self.triage_high = triage_high
        self.model = model
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.batch_size = batch_size
        self._prompt_builder = PromptBuilder(domain)
        self._client = self._build_client()

    def _build_client(self):
        try:
            from openai import OpenAI
            return OpenAI(api_key=self.openai_api_key)
        except ImportError:
            logger.warning("openai package not installed. Validation will return mock scores.")
            return None

    def _call_llm(self, prompt: str) -> str:
        """Single GPT-4o API call with retry logic."""
        if self._client is None:
            return json.dumps({
                "plausibility_score": 3,
                "score_rationale": "openai package not available — mock response.",
                "mechanism_assessment": "n/a",
                "domain_knowledge_assessment": "n/a",
                "contextual_applicability": "n/a",
                "implicit_assumptions": [],
                "contested_in_literature": False,
                "flag_for_expert_review": True,
                "failure_modes": [],
            })

        last_exc = None
        for attempt in range(self.max_retries):
            try:
                response = self._client.chat.completions.create(
                    model=self.model,
                    messages=[
                        {"role": "system", "content": _SYSTEM_PROMPT},
                        {"role": "user", "content": prompt},
                    ],
                    temperature=0.1,  # Low temperature for consistent scoring
                    response_format={"type": "json_object"},
                )
                return response.choices[0].message.content
            except Exception as exc:
                last_exc = exc
                logger.warning(f"API call failed (attempt {attempt + 1}): {exc}")
                time.sleep(self.retry_delay * (attempt + 1))

        raise RuntimeError(f"All {self.max_retries} API attempts failed: {last_exc}")

    def _parse_response(self, raw: str) -> ValidationResult:
        """Parse GPT-4o JSON response into a ValidationResult."""
        try:
            data = json.loads(raw)
            return ValidationResult(
                plausibility_score=int(data.get("plausibility_score", 3)),
                score_rationale=data.get("score_rationale", ""),
                mechanism_assessment=data.get("mechanism_assessment", ""),
                domain_knowledge_assessment=data.get("domain_knowledge_assessment", ""),
                contextual_applicability=data.get("contextual_applicability", ""),
                implicit_assumptions=data.get("implicit_assumptions", []),
                contested_in_literature=bool(data.get("contested_in_literature", False)),
                flag_for_expert_review=bool(data.get("flag_for_expert_review", False)),
                failure_modes=data.get("failure_modes", []),
                raw_response=raw,
                parse_error=False,
            )
        except (json.JSONDecodeError, KeyError, ValueError) as exc:
            logger.warning(f"Failed to parse validation response: {exc}")
            return ValidationResult(
                plausibility_score=3,
                score_rationale="Parse error — response did not conform to schema.",
                raw_response=raw,
                parse_error=True,
                flag_for_expert_review=True,
            )

    def _apply_triage(self, claim: CausalClaim) -> None:
        """
        Apply the uncertainty-aware triage rule to a validated claim.

        Sets ``claim.flagged_for_review = True`` when the plausibility
        score falls in the borderline band [triage_low, triage_high].
        """
        if claim.validation_score is None:
            claim.flagged_for_review = True
            return
        claim.flagged_for_review = (
            self.triage_low <= claim.validation_score <= self.triage_high
        )

    def validate_claim(self, claim: CausalClaim) -> CausalClaim:
        """
        Run Stage 1 validation on a single *claim*.

        Parameters
        ----------
        claim : CausalClaim

        Returns
        -------
        CausalClaim
            The same claim object with validation fields populated in-place.
        """
        prompt = self._prompt_builder.build(claim)
        raw = self._call_llm(prompt)
        result = self._parse_response(raw)

        claim.validation_score = result.plausibility_score
        claim.validation_rationale = result.score_rationale
        claim.validation_assumptions = result.implicit_assumptions
        claim.flagged_for_review = result.flag_for_expert_review
        self._apply_triage(claim)

        logger.info(
            f"Validated claim '{claim.cause_span[:40]}...' → "
            f"score={claim.validation_score}, flagged={claim.flagged_for_review}"
        )
        return claim

    def validate_claims(self, claims: list[CausalClaim]) -> list[CausalClaim]:
        """
        Run Stage 1 validation on a list of claims with batch rate management.

        Parameters
        ----------
        claims : list[CausalClaim]

        Returns
        -------
        list[CausalClaim]
            Claims with validation fields populated.
        """
        validated = []
        for i, claim in enumerate(claims):
            validated.append(self.validate_claim(claim))
            if (i + 1) % self.batch_size == 0 and i + 1 < len(claims):
                logger.debug(f"Batch {(i + 1) // self.batch_size} complete; "
                             f"sleeping 1s for rate management.")
                time.sleep(1.0)
        return validated

    def get_flagged_claims(self, claims: list[CausalClaim]) -> list[CausalClaim]:
        """
        Return only claims flagged for human expert review (Stage 2 triage).

        Parameters
        ----------
        claims : list[CausalClaim]
            Must have been processed by validate_claims() first.

        Returns
        -------
        list[CausalClaim]
        """
        return [c for c in claims if c.flagged_for_review]

    def apply_expert_labels(
        self, claims: list[CausalClaim], labels: dict[str, str]
    ) -> list[CausalClaim]:
        """
        Apply human expert labels to flagged claims (Stage 2).

        Parameters
        ----------
        claims : list[CausalClaim]
            Claims previously processed by validate_claims().
        labels : dict[str, str]
            Mapping from claim_id to expert label string
            (``"plausible"``, ``"contested"``, ``"implausible"``).

        Returns
        -------
        list[CausalClaim]
            Claims with expert_reviewed and expert_label fields updated.
        """
        for claim in claims:
            if claim.claim_id in labels:
                claim.expert_reviewed = True
                claim.expert_label = labels[claim.claim_id]
        return claims

    def compute_validation_statistics(self, claims: list[CausalClaim]) -> dict:
        """
        Compute aggregate validation statistics for a set of validated claims.

        Returns
        -------
        dict
            Keys: ``n_total``, ``n_validated``, ``n_flagged``,
            ``mean_score``, ``score_distribution``, ``flagged_rate``.
        """
        validated = [c for c in claims if c.validation_score is not None]
        flagged = [c for c in validated if c.flagged_for_review]
        scores = [c.validation_score for c in validated]
        score_dist = {i: scores.count(i) for i in range(1, 6)}
        return {
            "n_total": len(claims),
            "n_validated": len(validated),
            "n_flagged": len(flagged),
            "flagged_rate": len(flagged) / len(validated) if validated else 0.0,
            "mean_score": sum(scores) / len(scores) if scores else 0.0,
            "score_distribution": score_dist,
        }
